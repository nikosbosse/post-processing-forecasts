library(testthat)
library(postforecasts)

test_check("postforecasts")
